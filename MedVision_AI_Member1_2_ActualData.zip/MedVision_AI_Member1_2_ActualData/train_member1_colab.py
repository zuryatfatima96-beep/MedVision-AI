# Google Colab trainer for Member 1
from member1_oa import train_model

train_model(
    train_csv="/content/MedVisionAI/data/oa_train.csv",
    val_csv="/content/MedVisionAI/data/oa_val.csv",
    output_path="/content/MedVisionAI/models/oa_kl_efficientnet_b0.pt",
    epochs=15,
    batch_size=16,
    lr=2e-4
)
