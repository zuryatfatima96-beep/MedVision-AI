import os
import streamlit as st
from PIL import Image

from member1_oa import OAInference
from member2_anatomy import AnatomyInference, extract_landmarks, overlay_mask
from groq_assistant import build_report

st.set_page_config(page_title="MedVision AI", page_icon="🦴", layout="wide")
st.title("🦴 MedVision AI")
st.caption("Explainable multi-task knee X-ray research prototype")

OA_CKPT = "models/oa_kl_efficientnet_b0.pt"
SEG_CKPT = "models/anatomy_resnet18_unet.pt"

uploaded = st.file_uploader("Upload an AP knee X-ray", type=["png","jpg","jpeg"])
if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Uploaded knee X-ray", use_container_width=True)

    findings = {}

    if os.path.exists(OA_CKPT):
        oa = OAInference(OA_CKPT).predict(image)
        findings["oa"] = oa
        c1,c2,c3=st.columns(3)
        c1.metric("KL grade", oa["kl_label"])
        c2.metric("OA pattern", "Suspected" if oa["oa_suspected"] else "Not suspected")
        c3.metric("Confidence", f"{oa['confidence']:.1%}")
        st.subheader("Why did the model focus here?")
        st.image(oa["gradcam"], caption="Grad-CAM heatmap")
    else:
        st.warning("OA model checkpoint missing. Train Member 1 first.")

    if os.path.exists(SEG_CKPT):
        seg = AnatomyInference(SEG_CKPT).predict(image)
        landmarks = extract_landmarks(seg["mask"])
        findings["anatomy"] = {"landmarks": landmarks, "confidence": seg["confidence"]}
        st.subheader("Knee anatomy segmentation")
        st.image(overlay_mask(image, seg["mask"]), caption="Predicted bony anatomy")
        st.json(landmarks)
    else:
        st.warning("Anatomy model checkpoint missing. Train Member 2 first.")

    if st.button("Generate explainable AI report with Groq"):
        if findings:
            st.markdown(build_report(findings))
        else:
            st.error("No trained model is available.")

st.info("Research/hackathon prototype only. Not a medical diagnosis or a substitute for radiologist/orthopedic review.")
