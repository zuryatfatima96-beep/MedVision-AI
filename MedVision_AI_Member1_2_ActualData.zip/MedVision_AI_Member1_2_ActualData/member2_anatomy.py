"""Member 2: knee bony anatomy segmentation.

Classes for the Pitt/OAI-style four-bone task:
0 background, 1 femur, 2 tibia, 3 fibula, 4 patella.

The training pipeline is intentionally strict: masks must already be normalized
to integer class IDs. This prevents accidentally training on RGB label values.
"""

from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models

IMG_SIZE = 384

class AnatomyDataset(Dataset):
    def __init__(self, csv_file, num_classes=5, augment=False):
        self.df = pd.read_csv(csv_file)
        self.num_classes = num_classes
        self.augment = augment

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        row = self.df.iloc[i]
        image = Image.open(row.image_path).convert("RGB")
        mask = Image.open(row.mask_path).convert("L")

        image = image.resize((IMG_SIZE, IMG_SIZE), Image.Resampling.BILINEAR)
        mask = mask.resize((IMG_SIZE, IMG_SIZE), Image.Resampling.NEAREST)

        x = np.asarray(image, dtype=np.uint8)
        y = np.asarray(mask, dtype=np.int64)

        if self.augment and np.random.rand() < 0.5:
            x = np.ascontiguousarray(x[:, ::-1])
            y = np.ascontiguousarray(y[:, ::-1])

        if y.max() >= self.num_classes:
            raise ValueError(f"Invalid class {y.max()} in {row.mask_path}")

        x = torch.from_numpy(x).permute(2, 0, 1).float() / 255.0
        x = transforms.Normalize([0.485,0.456,0.406],
                                 [0.229,0.224,0.225])(x)
        y = torch.from_numpy(y).long()
        return x, y

class ConvBlock(nn.Module):
    def __init__(self, a, b):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(a,b,3,padding=1,bias=False),
            nn.BatchNorm2d(b), nn.ReLU(inplace=True),
            nn.Conv2d(b,b,3,padding=1,bias=False),
            nn.BatchNorm2d(b), nn.ReLU(inplace=True))
    def forward(self,x): return self.net(x)

class ResNet18UNet(nn.Module):
    """U-Net decoder with a pretrained ResNet18 encoder."""
    def __init__(self, num_classes=5):
        super().__init__()
        enc = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        self.stem = nn.Sequential(enc.conv1, enc.bn1, enc.relu)
        self.pool = enc.maxpool
        self.e1, self.e2 = enc.layer1, enc.layer2
        self.e3, self.e4 = enc.layer3, enc.layer4

        self.up4 = nn.ConvTranspose2d(512,256,2,2)
        self.d4 = ConvBlock(256+256,256)
        self.up3 = nn.ConvTranspose2d(256,128,2,2)
        self.d3 = ConvBlock(128+128,128)
        self.up2 = nn.ConvTranspose2d(128,64,2,2)
        self.d2 = ConvBlock(64+64,64)
        self.up1 = nn.ConvTranspose2d(64,64,2,2)
        self.d1 = ConvBlock(64+64,64)
        self.up0 = nn.ConvTranspose2d(64,32,2,2)
        self.head = nn.Conv2d(32,num_classes,1)

    def forward(self,x):
        s = self.stem(x)       # /2
        x = self.pool(s)       # /4
        e1 = self.e1(x)        # /4
        e2 = self.e2(e1)       # /8
        e3 = self.e3(e2)       # /16
        e4 = self.e4(e3)       # /32

        x = self.up4(e4)
        x = self.d4(torch.cat([x,e3],1))
        x = self.up3(x)
        x = self.d3(torch.cat([x,e2],1))
        x = self.up2(x)
        x = self.d2(torch.cat([x,e1],1))
        x = self.up1(x)
        # match /2 stem feature
        x = F.interpolate(x, size=s.shape[-2:], mode="bilinear", align_corners=False)
        x = self.d1(torch.cat([x,s],1))
        x = self.up0(x)
        return F.interpolate(self.head(x), size=(IMG_SIZE,IMG_SIZE),
                             mode="bilinear", align_corners=False)

def dice_loss(logits, target, classes):
    p = torch.softmax(logits,1)
    y = F.one_hot(target,classes).permute(0,3,1,2).float()
    inter = (p*y).sum((0,2,3))
    den = p.sum((0,2,3)) + y.sum((0,2,3))
    return 1 - ((2*inter+1e-6)/(den+1e-6)).mean()

@torch.no_grad()
def mean_iou(logits,target,classes):
    pred=logits.argmax(1)
    scores=[]
    per={}
    for c in range(1,classes):
        inter=((pred==c)&(target==c)).sum().item()
        union=((pred==c)|(target==c)).sum().item()
        v=inter/union if union else float("nan")
        per[c]=v
        if not np.isnan(v): scores.append(v)
    return (float(np.mean(scores)) if scores else 0.0), per

def train_segmentation(train_csv,val_csv,output_path="models/anatomy_resnet18_unet.pt",
                       num_classes=5,epochs=20,batch_size=4,lr=2e-4):
    device="cuda" if torch.cuda.is_available() else "cpu"
    tr=AnatomyDataset(train_csv,num_classes,augment=True)
    va=AnatomyDataset(val_csv,num_classes,augment=False)
    tl=DataLoader(tr,batch_size=batch_size,shuffle=True,num_workers=2,pin_memory=True)
    vl=DataLoader(va,batch_size=batch_size,shuffle=False,num_workers=2,pin_memory=True)
    model=ResNet18UNet(num_classes).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    best=-1
    Path(output_path).parent.mkdir(parents=True,exist_ok=True)

    for ep in range(1,epochs+1):
        model.train(); total=0
        for x,y in tl:
            x,y=x.to(device),y.to(device)
            opt.zero_grad(set_to_none=True)
            z=model(x)
            loss=F.cross_entropy(z,y)+dice_loss(z,y,num_classes)
            loss.backward(); opt.step(); total += loss.item()
        model.eval(); all_per=[]
        for x,y in vl:
            x,y=x.to(device),y.to(device)
            z=model(x)
            mi,per=mean_iou(z,y,num_classes)
            all_per.append((mi,per))
        score=float(np.mean([a[0] for a in all_per])) if all_per else 0
        print(f"Epoch {ep}: loss={total/max(1,len(tl)):.4f} mIoU={score:.4f}")
        if score>best:
            best=score
            torch.save({"model_state":model.state_dict(),
                        "img_size":IMG_SIZE,"num_classes":num_classes},output_path)
    print("Saved:",output_path)

class AnatomyInference:
    def __init__(self,checkpoint_path):
        self.device="cuda" if torch.cuda.is_available() else "cpu"
        ckpt=torch.load(checkpoint_path,map_location=self.device,weights_only=False)
        self.num_classes=ckpt["num_classes"]
        self.model=ResNet18UNet(self.num_classes)
        self.model.load_state_dict(ckpt["model_state"])
        self.model.to(self.device).eval()
        self.tf=transforms.Compose([
            transforms.Resize((ckpt.get("img_size",IMG_SIZE),
                               ckpt.get("img_size",IMG_SIZE))),
            transforms.ToTensor(),
            transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])])

    @torch.no_grad()
    def predict(self,image):
        x=self.tf(image.convert("RGB")).unsqueeze(0).to(self.device)
        p=torch.softmax(self.model(x),1)[0]
        mask=p.argmax(0).cpu().numpy().astype(np.uint8)
        confidence=p.max(0).values.mean().item()
        return {"mask":mask,"probabilities":p.cpu().numpy(),"confidence":confidence}

def extract_landmarks(mask):
    h,w=mask.shape
    out={}
    names={1:"femur",2:"tibia",3:"fibula",4:"patella"}
    for c,name in names.items():
        ys,xs=np.where(mask==c)
        if len(xs)==0: out[name]=None
        else:
            out[name]={"centroid":[float(xs.mean()/w),float(ys.mean()/h)],
                       "bbox":[float(xs.min()/w),float(ys.min()/h),
                               float(xs.max()/w),float(ys.max()/h)]}
    fy=np.where(mask==1)[0]; ty=np.where(mask==2)[0]
    out["joint_line"]=(
        {"y_normalized":float((np.percentile(fy,95)+np.percentile(ty,5))/(2*h))}
        if len(fy) and len(ty) else None)
    return out

def overlay_mask(image,mask,alpha=0.35):
    import cv2
    img=np.asarray(image.convert("RGB"))
    img=cv2.resize(img,(mask.shape[1],mask.shape[0])).astype(np.float32)
    palette={1:(255,0,0),2:(0,255,0),3:(0,0,255),4:(255,255,0)}
    out=img.copy()
    for cls,rgb in palette.items():
        region=mask==cls
        if region.any():
            c=np.asarray(rgb,dtype=np.float32)
            out[region]=(1-alpha)*out[region]+alpha*c
    return Image.fromarray(np.clip(out,0,255).astype(np.uint8))
