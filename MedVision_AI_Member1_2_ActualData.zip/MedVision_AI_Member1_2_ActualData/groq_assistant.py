import json
import os
from groq import Groq

DEFAULT_MODEL = "llama-3.3-70b-versatile"


def build_report(findings, model=DEFAULT_MODEL):
    key = os.getenv("GROQ_API_KEY")
    if not key:
        return "Groq is not configured. Set GROQ_API_KEY in Colab or Streamlit Secrets."

    client = Groq(api_key=key)

    prompt = f"""
You are the language/reporting layer of MedVision AI, a medical-imaging
hackathon prototype.

Use ONLY the structured computer-vision findings below.
Never invent an abnormality, measurement, disease, or diagnosis.
Do not recommend medication or treatment.
Use cautious language such as "AI-assisted finding" or "suggestive".
State that clinical review is required.

Structured findings:
{json.dumps(findings, indent=2)}

Return:
1. Key findings
2. AI impression
3. Safety note
"""

    r = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are a cautious medical imaging report assistant."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.1,
        max_completion_tokens=500,
    )

    return r.choices[0].message.content
