"""
Convert segmentation masks to class IDs.

IMPORTANT:
Do not run with guessed RGB values. First run inspect_segmentation_dataset.py.
Then set MAP below according to the actual published mask encoding.

For grayscale masks:
MAP = {0:0, background_value:0, femur_value:1, tibia_value:2, fibula_value:3, patella_value:4}

For RGB masks:
MAP can use tuples, e.g.
MAP = {(0,0,0):0, (255,0,0):1, ...}
"""

from pathlib import Path
import pandas as pd
import numpy as np
from PIL import Image

CSV_IN = Path("/content/MedVisionAI/data/seg_pairs.csv")
CSV_OUT = Path("/content/MedVisionAI/data/seg_pairs_normalized.csv")
OUT_DIR = Path("/content/MedVisionAI/data/seg_masks")

# FILL THIS AFTER INSPECTION OF THE REAL SAMPLE MASKS.
# Example only:
MAP = None

def normalize(arr):
    if MAP is None:
        raise RuntimeError(
            "Set MAP after running inspect_segmentation_dataset.py. "
            "Do not guess the anatomical label encoding."
        )
    out = np.zeros(arr.shape[:2], dtype=np.uint8)
    if arr.ndim == 2:
        for raw, cls in MAP.items():
            out[arr == raw] = cls
    else:
        for raw, cls in MAP.items():
            raw = np.asarray(raw, dtype=np.uint8)
            out[np.all(arr == raw, axis=-1)] = cls
    return out

def main():
    df = pd.read_csv(CSV_IN)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for _, r in df.iterrows():
        p = Path(r.mask_path)
        arr = np.asarray(Image.open(p))
        out = normalize(arr)
        dest = OUT_DIR / (p.stem + ".png")
        Image.fromarray(out).save(dest)
        rows.append({"image_path": r.image_path, "mask_path": str(dest)})
    pd.DataFrame(rows).to_csv(CSV_OUT, index=False)
    print("Saved:", CSV_OUT)

if __name__ == "__main__":
    main()
