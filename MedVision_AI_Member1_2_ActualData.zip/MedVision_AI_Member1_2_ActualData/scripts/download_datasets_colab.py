"""
Run this in Google Colab.

Downloads the real public datasets used by MedVision AI:
1) KneeXrayMini from Kaggle: KL 0-4 knee OA grading.
2) Pitt HexAI knee/hip bony anatomy repository: public sample X-rays
   + gold-standard manual segmentation masks.

The full OAI archive is NOT downloaded automatically because it has its own
access workflow. The Pitt repository documents that its complete study data
come from OAI, while the sample dataset is publicly available in the repo.
"""

from pathlib import Path
import subprocess, sys

BASE = Path("/content/MedVisionAI")
DATA = BASE / "data"
DATA.mkdir(parents=True, exist_ok=True)

subprocess.check_call([sys.executable, "-m", "pip", "install", "-q",
                       "kagglehub", "pandas", "pillow", "tqdm"])

import kagglehub

print("\n[1/2] Downloading KneeXrayMini...")
kaggle_path = kagglehub.dataset_download("tommyngx/kneexraymini")
print("KneeXrayMini downloaded to:", kaggle_path)

print("\n[2/2] Downloading Pitt HexAI segmentation repository...")
repo = BASE / "AI_Fairness_in_Hip_and_Knee_Bony_Anatomy_Segmentation"
if not repo.exists():
    subprocess.check_call([
        "git", "clone", "--depth", "1",
        "https://github.com/pitthexai/AI_Fairness_in_Hip_and_Knee_Bony_Anatomy_Segmentation.git",
        str(repo)
    ])
else:
    subprocess.check_call(["git", "-C", str(repo), "pull"])

print("\nDone.")
print("KneeXrayMini:", kaggle_path)
print("Segmentation repo:", repo)
print("Next:")
print("  python scripts/prepare_oa_dataset.py")
print("  python scripts/inspect_segmentation_dataset.py")
print("  python scripts/prepare_segmentation_dataset.py")
