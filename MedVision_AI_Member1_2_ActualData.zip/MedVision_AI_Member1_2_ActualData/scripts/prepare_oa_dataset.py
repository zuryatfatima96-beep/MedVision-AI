"""Create a KL-grade CSV from the downloaded KneeXrayMini folder."""

from pathlib import Path
import re
import pandas as pd

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}

def infer_kl(path: Path):
    parts = [p.lower() for p in path.parts]
    text = " ".join(parts)
    patterns = [
        r"(?:kl|grade|grading)[ _-]*([0-4])(?:[^0-9]|$)",
        r"(?:^|[_ -])([0-4])(?:[_ -]|$)",
    ]
    for pat in patterns:
        m = re.search(pat, text)
        if m:
            v = int(m.group(1))
            if 0 <= v <= 4:
                return v
    return None

def main():
    # KaggleHub usually returns a versioned cache directory. Change this if needed.
    import os
    src = Path(os.environ.get(
        "KNEEXRAYMINI_DIR",
        "/root/.cache/kagglehub/datasets/tommyngx/kneexraymini/versions/1"
    ))
    out = Path("/content/MedVisionAI/data/oa_all.csv")
    out.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for p in src.rglob("*"):
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS:
            kl = infer_kl(p)
            if kl is not None:
                rows.append({"image_path": str(p), "kl_grade": kl})

    df = pd.DataFrame(rows).drop_duplicates()
    if df.empty:
        raise RuntimeError(
            f"No KL-labelled images found under {src}. "
            "Set KNEEXRAYMINI_DIR to the extracted dataset directory."
        )

    df.to_csv(out, index=False)
    print(df["kl_grade"].value_counts().sort_index())
    print("Saved:", out, "rows:", len(df))

if __name__ == "__main__":
    main()
