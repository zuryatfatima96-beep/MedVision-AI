"""Patient-aware split when subject IDs are available; otherwise stratified image split."""

from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split

def subject_from_path(p):
    # Try common OAI/KneeXray naming conventions.
    s = Path(p).stem
    for token in ["_", "-", " "]:
        if token in s:
            first = s.split(token)[0]
            if len(first) >= 3:
                return first
    return s

def main(csv="/content/MedVisionAI/data/oa_all.csv"):
    df = pd.read_csv(csv)

    if "subject_id" not in df.columns:
        df["subject_id"] = df["image_path"].map(subject_from_path)

    # If IDs are clearly unique per image, image-level split is unavoidable.
    # The script still keeps the grouping interface explicit.
    groups = df["subject_id"].nunique()
    if groups >= max(10, int(0.5 * len(df))):
        train, temp = train_test_split(
            df, test_size=0.30, stratify=df["kl_grade"], random_state=42
        )
        val, test = train_test_split(
            temp, test_size=0.50, stratify=temp["kl_grade"], random_state=42
        )
        warning = "No reliable patient ID detected; this is a stratified image split."
    else:
        # Group split by subject ID.
        from sklearn.model_selection import GroupShuffleSplit
        gss = GroupShuffleSplit(n_splits=1, test_size=0.30, random_state=42)
        ti, vi = next(gss.split(df, groups=df["subject_id"]))
        train = df.iloc[ti].copy()
        temp = df.iloc[vi].copy()
        gss2 = GroupShuffleSplit(n_splits=1, test_size=0.50, random_state=42)
        vi2, te2 = next(gss2.split(temp, groups=temp["subject_id"]))
        val, test = temp.iloc[vi2].copy(), temp.iloc[te2].copy()
        warning = "Group split by subject_id."

    out = Path(csv).parent
    train.to_csv(out / "oa_train.csv", index=False)
    val.to_csv(out / "oa_val.csv", index=False)
    test.to_csv(out / "oa_test.csv", index=False)
    print(warning)
    print(len(train), len(val), len(test))

if __name__ == "__main__":
    main()
