"""
Build a segmentation CSV from the REAL Pitt sample repository.

The script tries to pair images and masks using normalized filename stems.
It does NOT silently assign semantic class IDs to RGB colors. Instead it
records the raw mask and prints the observed values. This prevents training
on an incorrect label mapping.

Expected CSV:
image_path,mask_path

After inspection, use normalize_mask.py to convert masks to:
0 background
1 femur
2 tibia
3 fibula
4 patella
"""

from pathlib import Path
import re, os
import pandas as pd

ROOT = Path(os.environ.get(
    "SEG_REPO",
    "/content/MedVisionAI/AI_Fairness_in_Hip_and_Knee_Bony_Anatomy_Segmentation"
))
OUT = Path("/content/MedVisionAI/data/seg_pairs.csv")
EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}

MASK_WORDS = ("mask", "label", "seg", "annotation", "groundtruth", "ground_truth")

def key(p):
    s = p.stem.lower()
    for w in MASK_WORDS:
        s = s.replace(w, "")
    s = re.sub(r"[^a-z0-9]+", "", s)
    return s

def main():
    sample = ROOT / "Sample_Dataset"
    if not sample.exists():
        raise FileNotFoundError(sample)

    all_files = [p for p in sample.rglob("*") if p.is_file() and p.suffix.lower() in EXTS]
    masks = [p for p in all_files if any(w in p.name.lower() for w in MASK_WORDS)]
    images = [p for p in all_files if p not in masks]

    mask_map = {}
    for m in masks:
        mask_map.setdefault(key(m), []).append(m)

    rows = []
    for im in images:
        candidates = mask_map.get(key(im), [])
        if len(candidates) == 1:
            rows.append({"image_path": str(im), "mask_path": str(candidates[0])})
        elif len(candidates) > 1:
            print("AMBIGUOUS:", im, candidates)

    df = pd.DataFrame(rows).drop_duplicates()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT, index=False)
    print("Images:", len(images), "Masks:", len(masks), "Pairs:", len(df))
    print("Saved:", OUT)

if __name__ == "__main__":
    main()
