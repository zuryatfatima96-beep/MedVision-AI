"""
Inspect the REAL Pitt sample dataset before training.

This is deliberately a separate step because the public repository may contain
different image/mask filename conventions and mask encodings. The script reports
files, dimensions, modes and unique mask values without guessing labels.
"""

from pathlib import Path
from PIL import Image
from collections import Counter
import os

ROOT = Path(os.environ.get(
    "SEG_REPO",
    "/content/MedVisionAI/AI_Fairness_in_Hip_and_Knee_Bony_Anatomy_Segmentation"
))
IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}

def describe(p):
    try:
        im = Image.open(p)
        vals = None
        if "mask" in p.name.lower() or "seg" in p.name.lower() or "label" in p.name.lower():
            if im.mode in ("L", "P", "1"):
                vals = sorted(set(im.getdata()))
            elif im.mode == "RGB":
                vals = Counter(im.getdata()).most_common(15)
        return im.size, im.mode, vals
    except Exception as e:
        return None, None, str(e)

def main():
    sample = ROOT / "Sample_Dataset"
    if not sample.exists():
        raise FileNotFoundError(sample)

    files = [p for p in sample.rglob("*") if p.is_file() and p.suffix.lower() in IMG_EXTS]
    print("Sample directory:", sample)
    print("Image-like files:", len(files))

    for p in files[:100]:
        size, mode, vals = describe(p)
        print(f"{p.relative_to(sample)} | size={size} mode={mode} values={vals}")

if __name__ == "__main__":
    main()
