"""MedVision AI - Member 1: OA + KL grading + Grad-CAM."""

from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
import torch.nn.functional as F

IMG_SIZE = 384
NUM_CLASSES = 5
CLASS_NAMES = ["KL-0", "KL-1", "KL-2", "KL-3", "KL-4"]


class KneeOADataset(Dataset):
    def __init__(self, csv_file, train=False):
        self.df = pd.read_csv(csv_file)
        if not {"image_path", "kl_grade"}.issubset(self.df.columns):
            raise ValueError("CSV must contain image_path and kl_grade.")

        if train:
            self.tfms = transforms.Compose([
                transforms.Resize((IMG_SIZE, IMG_SIZE)),
                transforms.RandomHorizontalFlip(0.5),
                transforms.RandomRotation(7),
                transforms.RandomAffine(0, translate=(0.03, 0.03), scale=(0.95, 1.05)),
                transforms.ColorJitter(brightness=0.12, contrast=0.12),
                transforms.ToTensor(),
                transforms.Normalize([0.485]*3, [0.229]*3),
            ])
        else:
            self.tfms = transforms.Compose([
                transforms.Resize((IMG_SIZE, IMG_SIZE)),
                transforms.ToTensor(),
                transforms.Normalize([0.485]*3, [0.229]*3),
            ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(row.image_path).convert("RGB")
        return self.tfms(image), torch.tensor(int(row.kl_grade), dtype=torch.long)


class OAClassifier(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        weights = models.EfficientNet_B0_Weights.DEFAULT if pretrained else None
        self.backbone = models.efficientnet_b0(weights=weights)
        n = self.backbone.classifier[1].in_features
        self.backbone.classifier = nn.Sequential(
            nn.Dropout(0.35),
            nn.Linear(n, NUM_CLASSES)
        )

    def forward(self, x):
        return self.backbone(x)


def class_weights(labels):
    counts = np.bincount(np.asarray(labels), minlength=NUM_CLASSES).astype(np.float32)
    counts[counts == 0] = 1
    return torch.tensor(counts.sum() / (NUM_CLASSES * counts), dtype=torch.float32)


def train_model(train_csv, val_csv, output_path="models/oa_kl_efficientnet_b0.pt",
                epochs=12, batch_size=16, lr=2e-4):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    train_ds = KneeOADataset(train_csv, True)
    val_ds = KneeOADataset(val_csv, False)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=2, pin_memory=device == "cuda")
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False,
                            num_workers=2, pin_memory=device == "cuda")

    model = OAClassifier().to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights(train_ds.df.kl_grade).to(device))
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    best = -1
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0

        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(x), y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        model.eval()
        correct = total = 0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                pred = model(x).argmax(1)
                correct += (pred == y).sum().item()
                total += len(y)

        acc = correct / max(total, 1)
        print(f"Epoch {epoch}/{epochs}: loss={train_loss/len(train_loader):.4f}, val_acc={acc:.4f}")

        if acc > best:
            best = acc
            torch.save({
                "model_state": model.state_dict(),
                "img_size": IMG_SIZE,
                "num_classes": NUM_CLASSES,
                "class_names": CLASS_NAMES,
            }, output_path)

    print("Saved:", output_path)


class GradCAM:
    def __init__(self, model, target_layer):
        self.model = model
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None

        target_layer.register_forward_hook(self._forward_hook)
        target_layer.register_full_backward_hook(self._backward_hook)

    def _forward_hook(self, module, inp, output):
        self.activations = output.detach()

    def _backward_hook(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def generate(self, x, class_idx=None):
        self.model.zero_grad(set_to_none=True)
        logits = self.model(x)

        if class_idx is None:
            class_idx = int(logits.argmax(1).item())

        logits[0, class_idx].backward()

        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = F.interpolate(
            cam, size=x.shape[-2:], mode="bilinear", align_corners=False
        )
        cam = cam[0, 0]
        cam -= cam.min()
        cam /= cam.max().clamp_min(1e-8)
        return cam.cpu().numpy(), class_idx


class OAInference:
    def __init__(self, checkpoint_path):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        ckpt = torch.load(checkpoint_path, map_location=self.device, weights_only=False)

        self.model = OAClassifier(pretrained=False)
        self.model.load_state_dict(ckpt["model_state"])
        self.model.to(self.device).eval()

        self.transform = transforms.Compose([
            transforms.Resize((ckpt.get("img_size", IMG_SIZE),
                               ckpt.get("img_size", IMG_SIZE))),
            transforms.ToTensor(),
            transforms.Normalize([0.485]*3, [0.229]*3),
        ])

        self.cam = GradCAM(self.model, self.model.backbone.features[-1])

    def predict(self, image, with_gradcam=True):
        image = image.convert("RGB")
        x = self.transform(image).unsqueeze(0).to(self.device)

        logits = self.model(x)
        probs = torch.softmax(logits, dim=1)[0]
        idx = int(probs.argmax())
        confidence = float(probs[idx])

        entropy = float(-(probs * torch.log(probs.clamp_min(1e-8))).sum())
        uncertainty = min(entropy / np.log(NUM_CLASSES), 1.0)

        result = {
            "kl_grade": idx,
            "kl_label": CLASS_NAMES[idx],
            "oa_suspected": idx >= 2,
            "confidence": confidence,
            "uncertainty": uncertainty,
            "probabilities": {
                CLASS_NAMES[i]: float(probs[i]) for i in range(NUM_CLASSES)
            }
        }

        if with_gradcam:
            cam, _ = self.cam.generate(x, idx)
            result["gradcam"] = cam

        return result
