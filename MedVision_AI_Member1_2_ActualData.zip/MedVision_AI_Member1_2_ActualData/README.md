# MedVision AI — Member 1 + Member 2 (Actual Dataset Edition)

This package turns the prototype into a reproducible pipeline using real public
knee-X-ray resources.

## 1. Real data

### Member 1 — OA / KL grading
**KneeXrayMini** is a public Kaggle dataset containing knee radiographs organized
for KL grading and derived from OAI material. The Kaggle page lists 9,786 files
and a CC0 public-domain license.

Dataset:
https://www.kaggle.com/datasets/tommyngx/kneexraymini

### Member 2 — bony anatomy segmentation
Use the **Pitt HexAI AI Fairness in Hip and Knee Bony Anatomy Segmentation**
repository. Its README states that `Sample_Dataset` contains plain radiographs
and gold-standard manual segmentations, and that the sample dataset and code
are freely available for research/education.

Repository:
https://github.com/pitthexai/AI_Fairness_in_Hip_and_Knee_Bony_Anatomy_Segmentation

The associated Scientific Reports paper describes plain-radiograph knee
segmentation and the study's OAI origin.

## 2. Google Colab — one-time setup

```bash
git clone https://github.com/YOUR_USERNAME/MedVisionAI.git
cd MedVisionAI
python scripts/download_datasets_colab.py
python scripts/prepare_oa_dataset.py
python scripts/split_oa_dataset.py
python scripts/inspect_segmentation_dataset.py
python scripts/prepare_segmentation_dataset.py
```

### IMPORTANT: mask labels

Do NOT guess the Pitt mask color/value mapping.

1. Run `inspect_segmentation_dataset.py`.
2. Inspect the reported grayscale/RGB values.
3. Set `MAP` in `scripts/normalize_masks.py`.
4. Run:
```bash
python scripts/normalize_masks.py
```

This protects the project from training on incorrect anatomical labels.

## 3. Train Member 1

```bash
python train_member1_colab.py
```

The model is EfficientNet-B0 with ImageNet transfer learning, class-weighted
KL cross-entropy, augmentation and Grad-CAM.

Report:
- macro F1
- per-class recall
- confusion matrix
- KL 0–4 accuracy
- calibration/confidence if time permits

## 4. Train Member 2

```bash
python train_member2_colab.py
```

The segmentation model is a U-Net-style decoder with a pretrained ResNet18
encoder and combined cross-entropy + Dice loss.

Report:
- mean IoU
- Dice per bone
- femur/tibia/fibula/patella IoU
- failure examples

## 5. Streamlit

Put these files in your GitHub repository:

```text
app.py
member1_oa.py
member2_anatomy.py
groq_assistant.py
requirements.txt
models/
  oa_kl_efficientnet_b0.pt
  anatomy_resnet18_unet.pt
```

Then deploy from Streamlit Community Cloud.

Add `GROQ_API_KEY` in Streamlit Secrets.

## 6. Groq's role

Groq is used as the reporting/explanation layer. It receives structured model
findings and is instructed not to invent measurements or diagnoses.

The core image decisions come from the trained PyTorch models.

## 7. Important scientific safeguards

- Do not call KL>=2 a definitive clinical diagnosis; use “radiographic OA
  pattern suspected”.
- Patient-level splitting is preferred. If the source data do not expose
  patient IDs, disclose the limitation.
- Segmentation-derived alignment/joint-line values are geometric prototypes,
  not validated clinical measurements.
- Do not claim fracture, effusion or other findings unless a separately trained
  and validated model exists for those findings.
- Always show a research/hackathon disclaimer.

## 8. Why this version is stronger

It uses actual downloadable datasets, a strict mask-inspection/normalization
step, a stronger pretrained segmentation encoder, uncertainty/confidence
display, Grad-CAM, and a Groq-generated explanation constrained to structured
model output.
