# Google Colab cell-style trainer
from scripts.prepare_segmentation_dataset import main as pair_masks
# First:
# !python scripts/inspect_segmentation_dataset.py
# Set the real label MAP in scripts/normalize_masks.py
# Then:
# !python scripts/normalize_masks.py

from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from member2_anatomy import train_segmentation

CSV = "/content/MedVisionAI/data/seg_pairs_normalized.csv"
df = pd.read_csv(CSV)
train, val = train_test_split(df, test_size=0.20, random_state=42)
train.to_csv("/content/MedVisionAI/data/seg_train.csv", index=False)
val.to_csv("/content/MedVisionAI/data/seg_val.csv", index=False)

train_segmentation(
    "/content/MedVisionAI/data/seg_train.csv",
    "/content/MedVisionAI/data/seg_val.csv",
    output_path="/content/MedVisionAI/models/anatomy_resnet18_unet.pt",
    num_classes=5,
    epochs=25,
    batch_size=4,
    lr=2e-4
)
